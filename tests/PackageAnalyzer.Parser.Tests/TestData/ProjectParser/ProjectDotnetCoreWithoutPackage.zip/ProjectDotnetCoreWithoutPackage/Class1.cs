﻿using System;

namespace ProjectDotnetCoreWithoutPackage
{
    public class Class1
    {
    }
}
