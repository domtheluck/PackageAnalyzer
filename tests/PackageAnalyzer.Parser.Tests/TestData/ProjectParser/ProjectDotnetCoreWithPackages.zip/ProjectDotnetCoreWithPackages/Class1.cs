﻿using System;

namespace ProjectDotnetCoreWithPackages
{
    public class Class1
    {
    }
}
