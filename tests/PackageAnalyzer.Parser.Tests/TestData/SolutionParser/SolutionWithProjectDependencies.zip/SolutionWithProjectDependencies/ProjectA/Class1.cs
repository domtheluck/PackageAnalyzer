﻿using System;

namespace ProjectA
{
    public class Class1
    {
    }
}
