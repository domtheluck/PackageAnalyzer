﻿using System;

namespace ProjectB
{
    public class Class1
    {
    }
}
