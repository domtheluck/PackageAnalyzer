﻿using System;

namespace ProjectC
{
    public class Class1
    {
    }
}
